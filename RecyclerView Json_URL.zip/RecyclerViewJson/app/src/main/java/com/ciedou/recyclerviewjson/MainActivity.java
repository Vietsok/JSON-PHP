package com.ciedou.recyclerviewjson;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {

    /** Vars Globales **/
    private RecyclerView recyclerView;
    private AdapterItem adapterItem;
    private ArrayList<ModelItem> itemArrayList;
    private RequestQueue requestQueue;
    private EditText editText;
    private Button button;

    /**Initialisation des composants**/
private void parseJSON(String tag){

    String urlJSONfile="https://pixabay.com/api/?key=24254416-d3b5c5634ff94625cc97e999d&q=nature&image_type=photo&pretty=true";
    JsonObjectRequest request=new JsonObjectRequest(Request.Method.GET, urlJSONfile, null, new Response.Listener<JSONObject>() {
        @Override
        public void onResponse(JSONObject response) {
            try {
                JSONArray jsonarray=response.getJSONArray("hits");
                for(int i=0;i<jsonarray.length();i++){
                    JSONObject hit=jsonarray.getJSONObject(i);
                    String creator=hit.getString("user");
                    int likes=hit.getInt("likes");
                    String imageUrl=hit.getString("webformatURL");
                    if(hit.getString("tags").contains(tag))
                        itemArrayList.add(new ModelItem(imageUrl,creator,likes));

                }
                adapterItem=new AdapterItem(MainActivity.this,itemArrayList);
                adapterItem.setOnItemClickListener(new AdapterItem.OnItemClickListener() {
                    @Override
                    public void onItemClick(int pos, View v) {
                        Intent i=new Intent(MainActivity.this,DisplayActivity.class);
                        i.putExtra("url",itemArrayList.get(pos).getImageUrl());
                        i.putExtra("auth",itemArrayList.get(pos).getCreator());
                        i.putExtra("likes",itemArrayList.get(pos).getLikes()+"");
                        startActivity(i);

                    }
                });
                recyclerView.setAdapter(adapterItem);


            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            error.printStackTrace();
        }
    });
    requestQueue.add(request);
}
    public void init(){
        recyclerView=findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        itemArrayList=new ArrayList<>();
        requestQueue= Volley.newRequestQueue(this);
        button=findViewById(R.id.button);
        editText=findViewById(R.id.editText);
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();


        parseJSON("");
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                itemArrayList.clear();
                parseJSON(editText.getText().toString().trim());
                editText.setText("");
            }
        });
    }
}