package com.ciedou.recyclerviewjson;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

public class DisplayActivity extends AppCompatActivity {

    ImageView tv;
    TextView  tva;
    TextView  tvl;



    public void init(){
        tv=findViewById(R.id.imageView);
        tva=findViewById(R.id.tva);
        tvl=findViewById(R.id.tvl);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        init();
        Context context=getApplicationContext();
        Intent myIntent=getIntent();
        String imageurl=myIntent.getStringExtra("url");
        String auth=myIntent.getStringExtra("auth");
        String likes=myIntent.getStringExtra("likes");
        tva.setText(auth);
        tvl.setText(likes);
        RequestOptions options=new RequestOptions().centerCrop().error(R.mipmap.ic_launcher).placeholder(R.mipmap.ic_launcher);
        Glide.with(context).load(imageurl).apply(options).fitCenter().diskCacheStrategy(DiskCacheStrategy.ALL).into(tv);
    }
}