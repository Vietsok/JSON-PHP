package com.lokavida.todelrecyclerviewfromvollay;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class AdapterItem extends RecyclerView.Adapter<AdapterItem.ItemViewHolder> {

    private Context context; // point d'accroche
    private ArrayList<ModelItem> itemArrayList; // tableau qui va comprendre toutes les informations nécessaires

    public AdapterItem(Context context, ArrayList<ModelItem> itemArrayList) {
        this.context = context;
        this.itemArrayList = itemArrayList;
    }


    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Accrocher la view - on caspule la vie
        View view = LayoutInflater.from(context).inflate(R.layout.item_recycler, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        ModelItem currentItem = itemArrayList.get(position); // recuperer la position

        // recuperer les datas
        String imageUrl = currentItem.getImageUrl();
        String creator = currentItem.getCreator();
        int likes = currentItem.getLikes();

        holder.tvCreator.setText(creator);
        holder.tvLikes.setText("likes :" + likes);



        /************************ GLIDE *************************************/
        // inserer glide pour afficher les images

        RequestOptions options = new RequestOptions() // gestion des erreurs
                .centerCrop()
                .error(R.mipmap.ic_launcher)
                .placeholder(R.mipmap.ic_launcher);



        // si jarrive pas a connecter
        Context context = holder.ivimageView.getContext();
        Glide
                .with(context)// avec la vue
                .load(imageUrl) // mettre une url / uri / text
                .apply(options)
                .fitCenter() // recadre image
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(holder.ivimageView); // emplacement ou afficher


        /************************ GLIDE *************************************/

    }

    @Override
    public int getItemCount() {
        return itemArrayList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        public ImageView ivimageView;
        public TextView tvCreator, tvLikes;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            ivimageView = itemView.findViewById(R.id.ivimageView);
            tvCreator = itemView.findViewById(R.id.tvCreator);
            tvLikes = itemView.findViewById(R.id.tvLikes);
        }
    }

}
