package com.lokavida.todelrecyclerviewfromvollay;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    /* global variable */

    private RecyclerView recyclerView;
    private AdapterItem adapterItem;

    /** pour faire fonctionner le adapter on a besoin du tableau **/
    private ArrayList<ModelItem> itemArrayList;

    private RequestQueue requestQueue; // file dattente des requetes;

    /* Initialisation des composants */

    public void init(){
        recyclerView = findViewById(R.id.recyclerView); // connection entre le graphisme et les data
        recyclerView.setHasFixedSize(true); // taille

        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // associer le nombre de ligne en fonction des entrées

        itemArrayList = new ArrayList<>();

        requestQueue = Volley.newRequestQueue(this);

    }

    // On va parser le JSON avec https://pixabay.com/api/docs/
        /** Methode pour parser le JSON **/

        private void parseJSON(){
    String urlJSONFile = "https://pixabay.com/api/?key=24254422-302d91095ecb99f9762286a04&q=nature&image=photo&pretty=true";

    JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, urlJSONFile, null, new Response.Listener<JSONObject>() {
        @Override
        public void onResponse(JSONObject response) {

            try {
                JSONArray jsonArray = response.getJSONArray("hits");

                for(int i = 0; i < jsonArray.length(); i++){

                    JSONObject hit =  jsonArray.getJSONObject(i);

                    String imageUrl= hit.getString("webformatURL");;
                    String creator = hit.getString("user");
                    int likes = hit.getInt("likes");

                    itemArrayList.add(new ModelItem(imageUrl, creator, likes));

                }

                adapterItem = new AdapterItem(getApplicationContext(), itemArrayList); // il atteint un context et un Arraylist

                // adapter recyclerview à l'adapter
                recyclerView.setAdapter(adapterItem);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            error.printStackTrace();

        }
    });

    requestQueue.add(request);





        }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        parseJSON();
    }
}